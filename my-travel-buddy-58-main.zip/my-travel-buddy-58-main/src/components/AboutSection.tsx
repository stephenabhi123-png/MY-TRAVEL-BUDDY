import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Globe, Award, Heart, Compass } from "lucide-react";

const stats = [
  { icon: Globe, value: "500+", label: "Destinations" },
  { icon: Heart, value: "10,000+", label: "Happy Travelers" },
  { icon: Award, value: "15+", label: "Years Experience" },
  { icon: Compass, value: "50+", label: "Expert Guides" },
];

const AboutSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" className="section-padding bg-background" ref={ref}>
      <div className="container mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <p className="text-accent font-medium tracking-[0.2em] uppercase text-sm mb-3">About Us</p>
            <h2 className="section-title !text-left">Your Trusted Travel Companion Since 2010</h2>
            <p className="text-muted-foreground leading-relaxed mb-6 font-body">
              At MY TRAVEL BUDDY, we believe every journey should be extraordinary. Founded with a passion for exploration and a commitment to excellence, we've been crafting unforgettable travel experiences for over 15 years.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8 font-body">
              Our team of seasoned travel experts works tirelessly to curate destinations, negotiate the best deals, and ensure every detail of your trip is perfect. From luxury escapes to thrilling adventures, we make your travel dreams a reality.
            </p>
            <a href="#contact" className="btn-primary-travel inline-block">Start Your Journey</a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="grid grid-cols-2 gap-6"
          >
            {stats.map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.4 + i * 0.1 }}
                className="glass-card rounded-2xl p-6 text-center group hover:-translate-y-1 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl gradient-ocean flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                  <stat.icon className="w-5 h-5 text-primary-foreground" />
                </div>
                <p className="font-display text-2xl font-bold text-foreground">{stat.value}</p>
                <p className="text-sm text-muted-foreground font-body mt-1">{stat.label}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
