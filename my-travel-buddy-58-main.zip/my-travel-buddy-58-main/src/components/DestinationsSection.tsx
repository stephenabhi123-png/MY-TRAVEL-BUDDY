import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import destBeach from "@/assets/dest-beach.jpg";
import destMountains from "@/assets/dest-mountains.jpg";
import destCity from "@/assets/dest-city.jpg";
import destAdventure from "@/assets/dest-adventure.jpg";

const destinations = [
  { title: "Beaches", subtitle: "Tropical Paradise", image: destBeach, count: "120+ spots" },
  { title: "Mountains", subtitle: "Peak Adventures", image: destMountains, count: "85+ trails" },
  { title: "Cities", subtitle: "Urban Exploration", image: destCity, count: "200+ cities" },
  { title: "Adventures", subtitle: "Thrill Seekers", image: destAdventure, count: "60+ experiences" },
];

const DestinationsSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="destinations" className="section-padding bg-background" ref={ref}>
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="text-accent font-medium tracking-[0.2em] uppercase text-sm mb-3">Discover</p>
          <h2 className="section-title">Popular Destinations</h2>
          <p className="section-subtitle">Explore our handpicked destinations that promise unforgettable experiences</p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {destinations.map((dest, i) => (
            <motion.div
              key={dest.title}
              initial={{ opacity: 0, y: 40 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: i * 0.15 }}
              className="card-travel group relative aspect-[3/4] cursor-pointer"
            >
              <img
                src={dest.image}
                alt={dest.title}
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/80 via-primary/20 to-transparent transition-all duration-500 group-hover:from-primary/90" />
              <div className="absolute bottom-0 left-0 right-0 p-6 text-primary-foreground">
                <p className="text-xs tracking-widest uppercase text-gold font-medium mb-1">{dest.count}</p>
                <h3 className="font-display text-2xl font-bold mb-1">{dest.title}</h3>
                <p className="text-sm text-primary-foreground/70 font-body">{dest.subtitle}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default DestinationsSection;
