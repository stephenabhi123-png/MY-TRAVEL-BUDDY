import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { MapPin, Calendar, Hotel, Route, Shield, Headphones } from "lucide-react";

const services = [
  { icon: MapPin, title: "Travel Planning", desc: "Expert-curated itineraries tailored to your dream destinations and travel style." },
  { icon: Calendar, title: "Tour Packages", desc: "All-inclusive packages with flights, accommodation, and guided experiences." },
  { icon: Hotel, title: "Hotel Booking", desc: "Handpicked luxury and boutique hotels at the best available rates." },
  { icon: Route, title: "Custom Itineraries", desc: "Personalized day-by-day plans crafted around your interests and pace." },
  { icon: Shield, title: "Travel Insurance", desc: "Comprehensive coverage for peace of mind on every adventure." },
  { icon: Headphones, title: "24/7 Support", desc: "Round-the-clock assistance wherever your journey takes you." },
];

const ServicesSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="services" className="section-padding bg-muted/50" ref={ref}>
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="text-accent font-medium tracking-[0.2em] uppercase text-sm mb-3">What We Offer</p>
          <h2 className="section-title">Our Services</h2>
          <p className="section-subtitle">Everything you need for a seamless and extraordinary travel experience</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, i) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="glass-card rounded-2xl p-8 group hover:-translate-y-2 transition-all duration-500 cursor-pointer"
            >
              <div className="w-14 h-14 rounded-xl gradient-sunset flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <service.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-display text-xl font-bold text-foreground mb-3">{service.title}</h3>
              <p className="text-muted-foreground font-body leading-relaxed">{service.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
