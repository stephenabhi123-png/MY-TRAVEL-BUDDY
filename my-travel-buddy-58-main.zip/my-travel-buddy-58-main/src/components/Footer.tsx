import { Plane } from "lucide-react";
import logoIcon from "@/assets/logo-icon.png";

const Footer = () => (
  <footer className="bg-primary text-primary-foreground py-16">
    <div className="container mx-auto px-4">
      <div className="grid md:grid-cols-4 gap-10 mb-12">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <img src={logoIcon} alt="Logo" width={36} height={36} />
            <span className="font-display text-lg font-bold">MY TRAVEL BUDDY</span>
          </div>
          <p className="text-primary-foreground/60 text-sm font-body leading-relaxed">
            Your perfect companion for unforgettable journeys. Crafting extraordinary travel experiences since 2010.
          </p>
        </div>
        {[
          { title: "Destinations", links: ["Beaches", "Mountains", "Cities", "Adventures"] },
          { title: "Company", links: ["About Us", "Services", "Packages", "Contact"] },
          { title: "Support", links: ["FAQs", "Travel Insurance", "Terms & Conditions", "Privacy Policy"] },
        ].map((col) => (
          <div key={col.title}>
            <h4 className="font-display font-bold mb-4">{col.title}</h4>
            <ul className="space-y-2">
              {col.links.map((link) => (
                <li key={link}>
                  <a href="#" className="text-primary-foreground/60 text-sm hover:text-gold transition-colors font-body">{link}</a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-primary-foreground/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
        <p className="text-primary-foreground/50 text-sm font-body">© 2025 MY TRAVEL BUDDY. All rights reserved.</p>
        <div className="flex items-center gap-2 text-primary-foreground/50 text-sm font-body">
          <Plane className="w-4 h-4" /> Made with passion for travel
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;
