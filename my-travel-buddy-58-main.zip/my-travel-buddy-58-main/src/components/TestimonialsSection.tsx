import { motion, useInView } from "framer-motion";
import { useRef, useState } from "react";
import { Star, ChevronLeft, ChevronRight, Quote } from "lucide-react";

const testimonials = [
  {
    name: "Sarah Johnson",
    location: "New York, USA",
    text: "MY TRAVEL BUDDY made our honeymoon absolutely magical. Every detail was perfectly planned, and the destinations they recommended were breathtaking.",
    rating: 5,
  },
  {
    name: "Marco Rivera",
    location: "Barcelona, Spain",
    text: "I've traveled with many agencies, but none compare to the personalized experience here. The custom itinerary felt like it was designed just for me.",
    rating: 5,
  },
  {
    name: "Aisha Patel",
    location: "Mumbai, India",
    text: "From the moment we reached out, the team was incredible. Our family trip was stress-free, fun, and full of amazing surprises. Highly recommend!",
    rating: 5,
  },
  {
    name: "James Chen",
    location: "Sydney, Australia",
    text: "The adventure package exceeded every expectation. Professional guides, stunning locations, and memories that will last a lifetime.",
    rating: 5,
  },
];

const TestimonialsSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });
  const [current, setCurrent] = useState(0);

  const next = () => setCurrent((c) => (c + 1) % testimonials.length);
  const prev = () => setCurrent((c) => (c - 1 + testimonials.length) % testimonials.length);

  const t = testimonials[current];

  return (
    <section id="testimonials" className="section-padding gradient-ocean" ref={ref}>
      <div className="container mx-auto max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <p className="text-gold font-medium tracking-[0.2em] uppercase text-sm mb-3">Testimonials</p>
          <h2 className="font-display text-3xl md:text-5xl font-bold text-primary-foreground mb-4">What Travelers Say</h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="glass-card-dark rounded-3xl p-8 md:p-12 text-center relative"
        >
          <Quote className="w-10 h-10 text-gold/40 mx-auto mb-6" />
          <motion.p
            key={current}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-lg md:text-xl text-primary-foreground/90 leading-relaxed mb-8 font-body"
          >
            "{t.text}"
          </motion.p>
          <div className="flex justify-center gap-1 mb-4">
            {Array.from({ length: t.rating }).map((_, i) => (
              <Star key={i} className="w-4 h-4 text-gold fill-gold" />
            ))}
          </div>
          <p className="font-display text-lg font-bold text-primary-foreground">{t.name}</p>
          <p className="text-sm text-primary-foreground/60 font-body">{t.location}</p>

          <div className="flex justify-center gap-3 mt-8">
            <button onClick={prev} className="w-10 h-10 rounded-full border border-primary-foreground/20 flex items-center justify-center text-primary-foreground/70 hover:bg-primary-foreground/10 transition-colors">
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrent(i)}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${i === current ? "bg-gold w-6" : "bg-primary-foreground/30"}`}
                />
              ))}
            </div>
            <button onClick={next} className="w-10 h-10 rounded-full border border-primary-foreground/20 flex items-center justify-center text-primary-foreground/70 hover:bg-primary-foreground/10 transition-colors">
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
