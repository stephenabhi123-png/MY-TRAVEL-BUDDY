import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Star, Clock, Users, Check } from "lucide-react";
import pkgLuxury from "@/assets/package-luxury.jpg";
import pkgAdventure from "@/assets/package-adventure.jpg";
import pkgRomantic from "@/assets/package-romantic.jpg";

const packages = [
  {
    image: pkgAdventure,
    title: "Adventure Explorer",
    price: "$1,299",
    duration: "7 Days",
    group: "Up to 12",
    rating: 4.8,
    features: ["Guided hikes", "Camping gear", "Meals included", "Photo tour"],
    badge: null,
  },
  {
    image: pkgLuxury,
    title: "Luxury Escape",
    price: "$3,499",
    duration: "10 Days",
    group: "Up to 6",
    rating: 4.9,
    features: ["5-star resorts", "Private transfers", "Spa sessions", "Fine dining", "Concierge"],
    badge: "Best Value",
  },
  {
    image: pkgRomantic,
    title: "Romantic Getaway",
    price: "$2,199",
    duration: "5 Days",
    group: "Couples",
    rating: 4.9,
    features: ["Beachfront suite", "Sunset cruise", "Couples spa", "Private dinner"],
    badge: null,
  },
];

const PackagesSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="packages" className="section-padding bg-background" ref={ref}>
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="text-accent font-medium tracking-[0.2em] uppercase text-sm mb-3">Best Deals</p>
          <h2 className="section-title">Featured Packages</h2>
          <p className="section-subtitle">Curated travel experiences at unbeatable prices</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {packages.map((pkg, i) => (
            <motion.div
              key={pkg.title}
              initial={{ opacity: 0, y: 40 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: i * 0.15 }}
              className={`card-travel bg-card group relative ${i === 1 ? "md:-translate-y-4 ring-2 ring-accent" : ""}`}
            >
              {pkg.badge && (
                <div className="absolute top-4 right-4 z-10 gradient-sunset text-primary font-bold text-xs px-4 py-1.5 rounded-full shadow-lg">
                  {pkg.badge}
                </div>
              )}
              <div className="relative h-52 overflow-hidden">
                <img src={pkg.image} alt={pkg.title} loading="lazy" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-1 mb-2">
                  <Star className="w-4 h-4 text-gold fill-gold" />
                  <span className="text-sm font-medium text-foreground">{pkg.rating}</span>
                </div>
                <h3 className="font-display text-xl font-bold text-foreground mb-2">{pkg.title}</h3>
                <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                  <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{pkg.duration}</span>
                  <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" />{pkg.group}</span>
                </div>
                <ul className="space-y-2 mb-6">
                  {pkg.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Check className="w-4 h-4 text-teal flex-shrink-0" />{f}
                    </li>
                  ))}
                </ul>
                <div className="flex items-end justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground">Starting from</p>
                    <p className="text-2xl font-display font-bold text-foreground">{pkg.price}</p>
                  </div>
                  <button className="btn-primary-travel !py-2.5 !px-6 !text-sm">Book Now</button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PackagesSection;
