import { motion, useInView } from "framer-motion";
import { useRef, useState } from "react";
import { X } from "lucide-react";
import destBeach from "@/assets/dest-beach.jpg";
import destMountains from "@/assets/dest-mountains.jpg";
import destCity from "@/assets/dest-city.jpg";
import destAdventure from "@/assets/dest-adventure.jpg";
import heroImage from "@/assets/hero-travel.jpg";
import pkgLuxury from "@/assets/package-luxury.jpg";
import pkgRomantic from "@/assets/package-romantic.jpg";
import pkgAdventure from "@/assets/package-adventure.jpg";

const images = [
  { src: heroImage, alt: "Tropical coastline", span: "col-span-2 row-span-2" },
  { src: destBeach, alt: "Beach paradise", span: "" },
  { src: destMountains, alt: "Mountain peaks", span: "" },
  { src: destCity, alt: "City skyline", span: "col-span-2" },
  { src: destAdventure, alt: "Jungle adventure", span: "" },
  { src: pkgLuxury, alt: "Luxury resort", span: "" },
  { src: pkgRomantic, alt: "Romantic sunset", span: "" },
  { src: pkgAdventure, alt: "Mountain hiking", span: "" },
];

const GallerySection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });
  const [lightbox, setLightbox] = useState<number | null>(null);

  return (
    <section id="gallery" className="section-padding bg-muted/50" ref={ref}>
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="text-accent font-medium tracking-[0.2em] uppercase text-sm mb-3">Memories</p>
          <h2 className="section-title">Travel Gallery</h2>
          <p className="section-subtitle">Glimpses of extraordinary moments from around the world</p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 auto-rows-[200px] md:auto-rows-[220px]">
          {images.map((img, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={inView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className={`${img.span} rounded-xl overflow-hidden cursor-pointer group relative`}
              onClick={() => setLightbox(i)}
            >
              <img src={img.src} alt={img.alt} loading="lazy" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
              <div className="absolute inset-0 bg-primary/0 group-hover:bg-primary/30 transition-all duration-500 flex items-center justify-center">
                <span className="text-primary-foreground font-display text-lg font-bold opacity-0 group-hover:opacity-100 transition-opacity duration-300">View</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {lightbox !== null && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-primary/90 flex items-center justify-center p-4"
          onClick={() => setLightbox(null)}
        >
          <button className="absolute top-6 right-6 text-primary-foreground" onClick={() => setLightbox(null)}>
            <X className="w-8 h-8" />
          </button>
          <img src={images[lightbox].src} alt={images[lightbox].alt} className="max-w-full max-h-[85vh] rounded-xl object-contain" />
        </motion.div>
      )}
    </section>
  );
};

export default GallerySection;
