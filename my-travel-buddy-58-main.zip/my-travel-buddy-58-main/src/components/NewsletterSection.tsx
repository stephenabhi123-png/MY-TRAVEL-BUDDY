import { motion, useInView } from "framer-motion";
import { useRef, useState } from "react";
import { Plane } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const NewsletterSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });
  const { toast } = useToast();
  const [email, setEmail] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: "Subscribed! ✈️", description: "Welcome aboard! Check your inbox for travel inspiration." });
    setEmail("");
  };

  return (
    <section className="py-16 gradient-ocean relative overflow-hidden" ref={ref}>
      <div className="absolute inset-0 opacity-10">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute text-primary-foreground"
            animate={{ x: ["-10%", "110%"], y: [20 + i * 60, 40 + i * 50] }}
            transition={{ repeat: Infinity, duration: 8 + i * 3, delay: i * 1.5, ease: "linear" }}
          >
            <Plane className="w-6 h-6" />
          </motion.div>
        ))}
      </div>
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center max-w-xl mx-auto"
        >
          <h3 className="font-display text-2xl md:text-3xl font-bold text-primary-foreground mb-3">Get Travel Inspiration</h3>
          <p className="text-primary-foreground/70 font-body mb-6">Subscribe for exclusive deals, travel tips, and destination guides.</p>
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
            <input
              type="email"
              required
              maxLength={255}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              className="flex-1 px-5 py-3.5 rounded-full bg-primary-foreground/10 border border-primary-foreground/20 text-primary-foreground placeholder:text-primary-foreground/40 outline-none focus:border-gold transition-colors font-body"
            />
            <button type="submit" className="btn-primary-travel !py-3.5 whitespace-nowrap">
              Subscribe ✦
            </button>
          </form>
        </motion.div>
      </div>
    </section>
  );
};

export default NewsletterSection;
